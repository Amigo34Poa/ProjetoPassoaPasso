@echo off
cd /d "%~dp0"
"%~dp0runtime\node.exe" --use-env-proxy "%~dp0server.cjs" --production --open --portable
pause
